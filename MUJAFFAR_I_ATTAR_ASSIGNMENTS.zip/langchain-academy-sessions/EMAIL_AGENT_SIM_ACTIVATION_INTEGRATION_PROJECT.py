"""
Vi SIM Activation Email Agent  |  Complete single-file Flask app
(extension of the Module 3.5 Email Agent)

Scenario:
  - After login, the agent scans the inbox for emails whose SUBJECT or BODY mentions SIM activation
  - It tells you who wrote in about SIM activation
  - It drafts a reply using ONLY the activation details and contacts you provide
    (sim_activation_details.txt, or details you type in the chat)
  - Every reply pauses for your review: Approve / Send my edit / Reject with note

Everything is in this one file:
  - Mimicked authentication (EmailContext + authenticate tool)
  - Middleware: dynamic tools, dynamic prompt, Human-in-the-Loop (approve / edit / reject)
  - Tools: check_inbox (mock), send_email (real Gmail SMTP or mock)
  - Flask UI with buttons for every HITL decision

Setup (once, in your .venv):
    pip install flask langchain langchain-openai langgraph python-dotenv

.env (same folder or any parent folder):
    OPENROUTER_API_KEY=sk-or-...          # or OPENAI_API_KEY=sk-proj-...
    GMAIL_ADDRESS=you@gmail.com           # optional - real sending
    GMAIL_APP_PASSWORD=16charapppassword  # optional - Gmail App Password (not your normal password)

Run:
    python email_agent_flask.py
Open:
    http://127.0.0.1:5000
"""

import os
import smtplib
import uuid
import warnings
from dataclasses import dataclass
from datetime import datetime
from email.message import EmailMessage
from typing import Callable

warnings.filterwarnings("ignore", message=".*Pydantic serializer warnings.*", category=UserWarning)
warnings.filterwarnings("ignore", message=".*PydanticSerializationUnexpectedValue.*")

from dotenv import find_dotenv, load_dotenv
from flask import Flask, redirect, render_template_string, request, session, url_for
from langchain.agents import AgentState, create_agent
from langchain.agents.middleware import (
    HumanInTheLoopMiddleware,
    ModelRequest,
    ModelResponse,
    dynamic_prompt,
    wrap_model_call,
)
from langchain.messages import HumanMessage, ToolMessage
from langchain.tools import ToolRuntime, tool
from langchain_openai import ChatOpenAI
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import Command

load_dotenv(find_dotenv(usecwd=True), override=True)

GMAIL_ADDRESS = os.getenv("GMAIL_ADDRESS")
GMAIL_APP_PASSWORD = os.getenv("GMAIL_APP_PASSWORD")


# =============================================================================
# 1. Context (mimicked login) and State
# =============================================================================
@dataclass
class EmailContext:
    # Demo login only. This is NOT your Gmail password and is never checked against Gmail.
    email_address: str = os.getenv("DEMO_LOGIN_EMAIL") or GMAIL_ADDRESS or "julie@example.com"
    password: str = os.getenv("DEMO_LOGIN_PASSWORD") or "demo123"


class AuthenticatedState(AgentState):
    authenticated: bool


DEMO = EmailContext()


# =============================================================================
# 2. Tools
# =============================================================================
# -----------------------------------------------------------------------------
# Mock inbox. The SIM activation customer defaults to your own Gmail
# (DEMO_SENDER_EMAIL or GMAIL_ADDRESS) so approved replies land in a real inbox.
# -----------------------------------------------------------------------------
CUSTOMER_EMAIL = os.getenv("DEMO_SENDER_EMAIL") or GMAIL_ADDRESS or "rahul.customer@example.com"

MOCK_INBOX = [
    {
        "id": 1,
        "from_name": "Rahul Sharma",
        "from_email": CUSTOMER_EMAIL,
        "subject": "SIM Activation request for new Vi connection",
        "body": (
            "Hello,\n"
            "I bought a new Vi SIM yesterday but it is not active yet. "
            "Could you please share the SIM activation process and whom I should contact?\n"
            "Thanks,\nRahul"
        ),
    },
    {
        "id": 2,
        "from_name": "Jane",
        "from_email": "jane@example.com",
        "subject": "Coffee next week?",
        "body": "Hi Julie, I'm in town next week - coffee?\n- Jane",
    },
    {
        "id": 3,
        "from_name": "Priya Nair",
        "from_email": "priya.customer@example.com",
        "subject": "Need help",
        "body": (
            "Hi team, I ported my number to Vi. How long does SIM activation take "
            "and what documents are needed?\nRegards, Priya"
        ),
    },
]

# Phrases that mark an email as a SIM activation request (case-insensitive, subject OR body)
SIM_KEYWORDS = ["sim activation", "activate sim", "activate my sim", "sim not active", "activation of sim"]


def is_sim_activation(email: dict) -> bool:
    text = f"{email['subject']} {email['body']}".lower()
    return any(k in text for k in SIM_KEYWORDS)


def sim_activation_emails() -> list[dict]:
    return [e for e in MOCK_INBOX if is_sim_activation(e)]


def format_email(e: dict) -> str:
    return (
        f"[Email {e['id']}] From: {e['from_name']} <{e['from_email']}>\n"
        f"Subject: {e['subject']}\n{e['body']}"
    )


# -----------------------------------------------------------------------------
# YOUR activation details and contacts. Edit sim_activation_details.txt
# (same folder). The agent is told to use ONLY this text.
# -----------------------------------------------------------------------------
DETAILS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sim_activation_details.txt")
DEFAULT_DETAILS = """SIM activation process:
1. <step 1 - fill in>
2. <step 2 - fill in>
3. <step 3 - fill in>

Documents required: <fill in>
Expected activation time: <fill in>

Contact for SIM activation:
Name / team: <fill in>
Phone: <fill in>
Email: <fill in>
Working hours: <fill in>"""


def load_details() -> str:
    try:
        with open(DETAILS_FILE, encoding="utf-8") as f:
            return f.read().strip() or DEFAULT_DETAILS
    except FileNotFoundError:
        return DEFAULT_DETAILS


def details_have_placeholders() -> bool:
    return "<" in load_details() and "fill in" in load_details().lower()


@tool
def check_inbox() -> str:
    """Check the inbox and return all recent emails"""
    return "\n\n".join(format_email(e) for e in MOCK_INBOX)


@tool
def find_sim_activation_emails() -> str:
    """Find emails whose subject or body is about SIM activation"""
    found = sim_activation_emails()
    print(f"[find_sim_activation_emails] {len(found)} found")
    if not found:
        return "No SIM activation emails found."
    return f"Found {len(found)} SIM activation email(s):\n\n" + "\n\n".join(format_email(e) for e in found)


@tool
def get_sim_activation_details() -> str:
    """Get the official SIM activation process and contact details to share with customers"""
    return load_details()


@tool
def send_email(to: str, subject: str, body: str) -> str:
    """Send a response email"""
    if not GMAIL_ADDRESS or not GMAIL_APP_PASSWORD:
        result = f"[MOCK] Email sent to {to} with subject '{subject}'"
    elif "@" not in to:
        result = f"Failed to send email: '{to}' is not an email address"
    else:
        msg = EmailMessage()
        msg["From"] = GMAIL_ADDRESS
        msg["To"] = to
        msg["Subject"] = subject
        msg.set_content(body)
        try:
            with smtplib.SMTP_SSL("smtp.gmail.com", 465, timeout=20) as smtp:
                smtp.login(GMAIL_ADDRESS, GMAIL_APP_PASSWORD)
                smtp.send_message(msg)
            result = f"Email actually sent to {to} with subject '{subject}'"
        except Exception as e:
            result = f"Failed to send email: {e}"
    print(f"[send_email] {result}")
    return result


@tool
def authenticate(email: str, password: str, runtime: ToolRuntime) -> Command:
    """Authenticate the user with the given email and password"""
    ctx = runtime.context or EmailContext()
    ok = email.strip().lower() == ctx.email_address.lower() and password.strip() == ctx.password
    print(f"[authenticate] email={email!r} expected={ctx.email_address!r} match={ok}")
    return Command(
        update={
            "authenticated": ok,
            "messages": [
                ToolMessage(
                    "Successfully authenticated" if ok else "Authentication failed",
                    tool_call_id=runtime.tool_call_id,
                )
            ],
        }
    )


# =============================================================================
# 3. Middleware - dynamic tools + dynamic prompt
# =============================================================================
@wrap_model_call
def dynamic_tool_call(request: ModelRequest, handler: Callable[[ModelRequest], ModelResponse]) -> ModelResponse:
    """Before login: only authenticate. After login: inbox, SIM tools and send_email."""
    if request.state.get("authenticated"):
        tools = [check_inbox, find_sim_activation_emails, get_sim_activation_details, send_email]
    else:
        tools = [authenticate]
    return handler(request.override(tools=tools))


AUTHENTICATED_PROMPT = """You are a Vi customer-support email assistant.

After authentication:
1. Call find_sim_activation_emails.
2. If SIM activation emails exist, first tell the user in one line per email:
   "There is an email from <name> (<email>) about SIM activation: <subject>".
3. Call get_sim_activation_details and draft a polite reply to each SIM activation email.
   - Address the customer by name and answer what they asked.
   - Use ONLY the activation steps, documents, timelines and contacts from get_sim_activation_details,
     or details the user gives you in this chat (the user's details take priority).
   - Never invent steps, phone numbers, emails, links or timelines. If something is missing, leave it out.
   - Use the customer's full email address as 'to' and "Re: <original subject>" as the subject.
   - Sign off as "Vi Customer Support".
4. Send replies ONE AT A TIME with send_email. A human reviews each one before it is sent.
5. If a reply is rejected with feedback, revise it and call send_email again. If rejected without
   feedback, do not retry; ask the user what to change.
6. If a human edited the email, just confirm what was sent.
7. Ignore emails that are not about SIM activation unless the user asks about them.
If there are no SIM activation emails, say so and briefly summarise the inbox."""

UNAUTHENTICATED_PROMPT = """You are a helpful assistant that can authenticate users.
Ask the user for their email and password, then call the authenticate tool.
Do not help with anything else until the user is authenticated."""


@dynamic_prompt
def prompt_by_auth(request: ModelRequest) -> str:
    return AUTHENTICATED_PROMPT if request.state.get("authenticated") else UNAUTHENTICATED_PROMPT


# =============================================================================
# 4. Model + Agent (with Human-in-the-Loop on send_email)
# =============================================================================
if os.getenv("OPENROUTER_API_KEY"):
    model = ChatOpenAI(
        model=os.getenv("EMAIL_AGENT_MODEL", "openai/gpt-4o-mini"),
        api_key=os.getenv("OPENROUTER_API_KEY"),
        base_url="https://openrouter.ai/api/v1",
    )
else:
    model = "gpt-5-nano"  # uses OPENAI_API_KEY

agent = create_agent(
    model,
    tools=[authenticate, check_inbox, find_sim_activation_emails, get_sim_activation_details, send_email],
    checkpointer=InMemorySaver(),
    state_schema=AuthenticatedState,
    context_schema=EmailContext,
    middleware=[
        dynamic_tool_call,
        prompt_by_auth,
        HumanInTheLoopMiddleware(
            interrupt_on={
                "authenticate": False,
                "check_inbox": False,
                "send_email": {"allowed_decisions": ["approve", "edit", "reject"]},
            }
        ),
    ],
)


# =============================================================================
# 5. Flask helpers
# =============================================================================
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET", "dev-secret-change-me")
DECISIONS: dict[str, list] = {}  # thread_id -> list of decisions
ERRORS: dict[str, str] = {}      # thread_id -> last error


def thread_id() -> str:
    if "thread_id" not in session:
        session["thread_id"] = str(uuid.uuid4())
    return session["thread_id"]


def cfg() -> dict:
    return {"configurable": {"thread_id": thread_id()}}


def run_agent(payload) -> None:
    ERRORS.pop(thread_id(), None)
    try:
        agent.invoke(payload, context=EmailContext(), config=cfg())
    except Exception as e:
        ERRORS[thread_id()] = f"{type(e).__name__}: {e}"
        print(f"[error] {ERRORS[thread_id()]}")


def pending_emails() -> list:
    """All send_email calls currently waiting for review (usually 1)."""
    state = agent.get_state(cfg())
    if state.interrupts:
        return state.interrupts[0].value["action_requests"]
    return []


def text_of(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(b.get("text", "") if isinstance(b, dict) else str(b) for b in content)
    return str(content)


def build_timeline(messages):
    rows = []
    for m in messages:
        if m.type == "human":
            rows.append({"kind": "user", "text": text_of(m.content)})
        elif m.type == "ai":
            if text_of(m.content).strip():
                rows.append({"kind": "agent", "text": text_of(m.content)})
            for tc in m.tool_calls:
                label = {
                    "authenticate": f"Checking login for {tc['args'].get('email', '')}",
                    "check_inbox": "Reading the inbox",
                    "find_sim_activation_emails": "Scanning inbox for SIM activation requests",
                    "get_sim_activation_details": "Loading your SIM activation details",
                    "send_email": f"Drafted an email to {tc['args'].get('to', '')}",
                }.get(tc["name"], tc["name"])
                rows.append({"kind": "tool-call", "text": label})
        elif m.type == "tool":
            content = text_of(m.content).strip()
            if m.name == "send_email":
                if "human reviewer replaced" in content:
                    content = "Reviewer edited the email. " + content.split("Tool response:")[-1].strip()
                elif content.startswith("User rejected"):
                    content = "Reviewer rejected the draft. " + (
                        "Note: " + content.split("with reason:")[-1].strip() if "with reason:" in content else "No note."
                    )
            rows.append({"kind": "tool-result", "name": m.name, "text": content})
    return rows


# =============================================================================
# 6. Page template
# =============================================================================
PAGE = """
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Vi SIM Activation Agent</title>
<style>
  body { font-family: "Segoe UI", system-ui, sans-serif; background:#eef1f5; color:#1c2b4a; margin:0; }
  .wrap { max-width:1050px; margin:0 auto; padding:20px; display:grid; grid-template-columns:1fr 290px; gap:20px; }
  @media (max-width:820px){ .wrap{ grid-template-columns:1fr; } }
  h1 { font-size:20px; margin:0 0 4px; }
  .card { background:#fff; border:1px solid #d5dbe3; border-radius:8px; padding:16px; margin-bottom:14px; }
  .row { margin:8px 0; }
  .user { text-align:right; }
  .user span, .agent span { display:inline-block; padding:8px 12px; border-radius:12px; max-width:80%; white-space:pre-wrap; text-align:left; }
  .user span { background:#1c2b4a; color:#fff; }
  .agent span { background:#f3f5f8; border:1px solid #d5dbe3; }
  .tool-call { color:#56627a; font-size:13px; }
  .tool-result { font-size:13px; background:#f7f9fb; border-left:3px solid #9aa6bd; padding:6px 10px; white-space:pre-wrap; }
  .tool-result.send_email { border-color:#2f7d57; }
  .review { border:2px solid #c8323c; }
  .review h2 { margin-top:0; font-size:18px; }
  label { font-size:13px; color:#56627a; display:block; margin-top:8px; }
  input[type=text], textarea { width:100%; box-sizing:border-box; padding:8px; border:1px solid #c5ccd6; border-radius:6px; font:inherit; }
  textarea { min-height:130px; }
  button { padding:8px 14px; border-radius:6px; border:1px solid #c5ccd6; background:#fff; cursor:pointer; font:inherit; margin:8px 6px 0 0; }
  .approve { background:#2f7d57; color:#fff; border-color:#2f7d57; }
  .edit { background:#2e5aac; color:#fff; border-color:#2e5aac; }
  .reject { color:#c8323c; border-color:#c8323c; }
  .primary { background:#1c2b4a; color:#fff; border-color:#1c2b4a; }
  .err { background:#fff0f0; border:1px solid #c8323c; color:#c8323c; padding:10px; border-radius:6px; white-space:pre-wrap; margin-bottom:14px; }
  .muted { color:#56627a; font-size:13px; }
  .badge { display:inline-block; padding:2px 10px; border-radius:999px; font-size:13px; border:1px solid; margin:4px 0; }
  .yes { color:#2f7d57; } .no { color:#56627a; }
  ul { padding-left:18px; } li { margin-bottom:6px; font-size:14px; }
  .inline { display:inline; }
  .sim { border-left:4px solid #c8102e; }
  .warn { color:#a3620b; font-size:13px; }
  .req + .req { border-top:1px dashed #c5ccd6; margin-top:14px; padding-top:10px; }
  .choice label { display:inline; margin-right:12px; color:#1c2b4a; font-size:14px; }
</style>
</head>
<body>
<div class="wrap">
  <main>
    <h1>Vi SIM activation email agent</h1>
    <p class="muted">Demo login: {{ demo.email_address }} / {{ demo.password }} &nbsp;|&nbsp; Sending: {{ mode }}</p>

    <div class="card">
      {% if not rows %}<p class="muted">No messages yet. Click "Log in (demo)" to start. After login the agent scans the inbox for SIM activation requests.</p>{% endif %}
      {% for r in rows %}
        {% if r.kind == "user" %}<div class="row user"><span>{{ r.text }}</span></div>
        {% elif r.kind == "agent" %}<div class="row agent"><span>{{ r.text }}</span></div>
        {% elif r.kind == "tool-call" %}<div class="row tool-call">&rarr; {{ r.text }}</div>
        {% else %}<div class="row tool-result {{ r.name }}"><b>{{ r.name }}:</b> {{ r.text }}</div>
        {% endif %}
      {% endfor %}
    </div>

    {% if error %}<div class="err">{{ error }}</div>{% endif %}

    {% if pending %}
    <div class="card review">
      <h2>Review {{ "this email" if pending|length == 1 else pending|length ~ " emails" }} before sending</h2>
      <form method="post" action="{{ url_for('decide') }}">
        {% for p in pending %}{% set i = loop.index0 %}
        <div class="req">
          {% if pending|length > 1 %}<b>Email {{ loop.index }}</b>{% endif %}
          <label>To</label><input type="text" name="to_{{ i }}" value="{{ p.args.to }}">
          <label>Subject</label><input type="text" name="subject_{{ i }}" value="{{ p.args.subject }}">
          <label>Body</label><textarea name="body_{{ i }}">{{ p.args.body }}</textarea>
          <label>Note for the agent (only used with Reject)</label>
          <input type="text" name="note_{{ i }}" placeholder="e.g. Add the working hours and keep it shorter">
          {% if pending|length > 1 %}
          <div class="choice">
            <label><input type="radio" name="decision_{{ i }}" value="approve" checked> Approve</label>
            <label><input type="radio" name="decision_{{ i }}" value="edit"> Send my edit</label>
            <label><input type="radio" name="decision_{{ i }}" value="reject"> Reject with note</label>
          </div>
          {% endif %}
        </div>
        {% endfor %}
        <div>
        {% if pending|length == 1 %}
          <button class="approve" name="decision_0" value="approve">Approve (send as drafted)</button>
          <button class="edit" name="decision_0" value="edit">Send my edited version</button>
          <button class="reject" name="decision_0" value="reject">Reject with note</button>
        {% else %}
          <button class="primary">Submit decisions</button>
        {% endif %}
        </div>
      </form>
    </div>
    {% else %}
    <div class="card">
      <form method="post" action="{{ url_for('send') }}">
        <input type="text" name="message" placeholder="Message the agent" autofocus>
        <button class="primary">Send</button>
      </form>
      <form method="post" action="{{ url_for('send') }}" class="inline">
        <input type="hidden" name="message" value="Please log me in. My email is {{ demo.email_address }} and my password is {{ demo.password }}.">
        <button>Log in (demo)</button>
      </form>
      <form method="post" action="{{ url_for('send') }}" class="inline">
        <input type="hidden" name="message" value="Please log me in. My email is {{ demo.email_address }} and my password is wrongpass.">
        <button>Try wrong password</button>
      </form>
      <form method="post" action="{{ url_for('send') }}" class="inline">
        <input type="hidden" name="message" value="Please reply to the SIM activation emails using the activation details.">
        <button>Reply to SIM activation requests</button>
      </form>
    </div>
    {% endif %}
  </main>

  <aside>
    <div class="card">
      <b>Login status</b><br>
      {% if authenticated %}<span class="badge yes">Logged in</span>{% else %}<span class="badge no">Logged out</span>{% endif %}
      <p class="muted">Tools the agent can use now:<br>
        {% if authenticated %}check_inbox, find_sim_activation_emails, get_sim_activation_details, send_email (needs your approval){% else %}authenticate only{% endif %}</p>
    </div>
    {% if authenticated %}
    <div class="card sim">
      <b>SIM activation requests</b>
      {% if sim_emails %}
      <ul>{% for e in sim_emails %}<li><b>{{ e.from_name }}</b><br><span class="muted">{{ e.from_email }}<br>{{ e.subject }}</span></li>{% endfor %}</ul>
      {% else %}<p class="muted">None in the inbox.</p>{% endif %}
      {% if placeholders %}<p class="warn">Your activation details still contain &lt;fill in&gt; placeholders. Edit sim_activation_details.txt before the demo.</p>{% endif %}
    </div>
    {% endif %}
    <div class="card">
      <b>Your decisions</b>
      {% if decisions %}
      <ul>{% for d in decisions %}<li><b>{{ d.type }}</b> at {{ d.time }}{% if d.detail %}<br><span class="muted">{{ d.detail }}</span>{% endif %}</li>{% endfor %}</ul>
      {% else %}<p class="muted">None yet.</p>{% endif %}
    </div>
    <form method="post" action="{{ url_for('new_thread') }}"><button>Start new conversation</button></form>
    <p class="muted">Conversation: {{ tid[:8] }}</p>
  </aside>
</div>
</body>
</html>
"""


# =============================================================================
# 7. Routes
# =============================================================================
@app.get("/")
def index():
    values = agent.get_state(cfg()).values or {}
    return render_template_string(
        PAGE,
        rows=build_timeline(values.get("messages", [])),
        authenticated=values.get("authenticated", False),
        pending=pending_emails(),
        sim_emails=sim_activation_emails(),
        placeholders=details_have_placeholders(),
        decisions=DECISIONS.get(thread_id(), []),
        error=ERRORS.get(thread_id()),
        demo=DEMO,
        mode="real Gmail" if (GMAIL_ADDRESS and GMAIL_APP_PASSWORD) else "mock (no Gmail values in .env)",
        tid=thread_id(),
    )


@app.post("/send")
def send():
    msg = request.form.get("message", "").strip()
    if msg and not pending_emails():  # never send chat while a review is waiting
        run_agent({"messages": [HumanMessage(msg)]})
    return redirect(url_for("index"))


@app.post("/decide")
def decide():
    pending = pending_emails()
    if not pending:
        return redirect(url_for("index"))

    decisions = []
    for i, p in enumerate(pending):
        choice = request.form.get(f"decision_{i}", "approve")
        edited = {k: request.form.get(f"{k}_{i}", "") for k in ("to", "subject", "body")}
        note = request.form.get(f"note_{i}", "").strip()

        if choice == "approve":
            decision = {"type": "approve"}
            detail = f"to {p['args'].get('to')}"
        elif choice == "edit":
            decision = {"type": "edit", "edited_action": {"name": p["name"], "args": edited}}
            detail = f"to {edited['to']}, subject: {edited['subject']}"
        else:
            decision = {"type": "reject", "message": note} if note else {"type": "reject"}
            detail = f"note: {note}" if note else "no note"

        decisions.append(decision)
        DECISIONS.setdefault(thread_id(), []).append(
            {"type": choice, "detail": detail, "time": datetime.now().strftime("%H:%M:%S")}
        )
        print(f"[decision] {choice} - {detail}")

    run_agent(Command(resume={"decisions": decisions}))
    return redirect(url_for("index"))


@app.post("/new")
def new_thread():
    session["thread_id"] = str(uuid.uuid4())
    return redirect(url_for("index"))


if __name__ == "__main__":
    print(f"Demo login  : {DEMO.email_address} / {DEMO.password}")
    print(f"SIM details : {DETAILS_FILE}{' (placeholders - please fill in)' if details_have_placeholders() else ''}")
    print(f"Sending mode: {'real Gmail' if (GMAIL_ADDRESS and GMAIL_APP_PASSWORD) else 'mock'}")
    print("Open http://127.0.0.1:5000")
    app.run(debug=True, port=5000, use_reloader=False)
